
// Utility functions for PixResize

window.PixUtils = {
  formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  },

  clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  },

  loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  },

  canvasToBlob(canvas, format, quality) {
    return new Promise(resolve => {
      const mime = format === 'jpg' ? 'image/jpeg'
        : format === 'png' ? 'image/png'
        : format === 'webp' ? 'image/webp'
        : 'image/avif';
      canvas.toBlob(resolve, mime, quality / 100);
    });
  },

  // Apply all processing to a canvas
  async processImage(originalSrc, settings) {
    const { resize, transform, adjustments, watermark } = settings;

    const img = await PixUtils.loadImage(originalSrc);

    // Determine output dimensions
    let outW = img.naturalWidth;
    let outH = img.naturalHeight;

    if (resize.enabled) {
      if (resize.mode === 'pixels') {
        outW = parseInt(resize.width) || img.naturalWidth;
        outH = parseInt(resize.height) || img.naturalHeight;
      } else if (resize.mode === 'percent') {
        const pct = parseFloat(resize.percent) / 100;
        outW = Math.round(img.naturalWidth * pct);
        outH = Math.round(img.naturalHeight * pct);
      }
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    // Handle rotation for dimension swap
    const rot = transform.rotation % 360;
    const swap = rot === 90 || rot === 270;
    canvas.width = swap ? outH : outW;
    canvas.height = swap ? outW : outH;

    ctx.save();

    // Apply transforms
    ctx.translate(canvas.width / 2, canvas.height / 2);
    if (transform.rotation) ctx.rotate((transform.rotation * Math.PI) / 180);
    if (transform.flipH) ctx.scale(-1, 1);
    if (transform.flipV) ctx.scale(1, -1);

    // Filters
    const filters = [];
    if (adjustments.brightness !== 100) filters.push(`brightness(${adjustments.brightness}%)`);
    if (adjustments.contrast !== 100) filters.push(`contrast(${adjustments.contrast}%)`);
    if (adjustments.blur > 0) filters.push(`blur(${adjustments.blur}px)`);
    if (adjustments.grayscale) filters.push('grayscale(100%)');
    if (filters.length) ctx.filter = filters.join(' ');

    // Draw with fit mode
    const fitMode = resize.fitMode || 'contain';
    let sx = 0, sy = 0, sw = img.naturalWidth, sh = img.naturalHeight;
    let dx = -outW / 2, dy = -outH / 2, dw = outW, dh = outH;

    if (fitMode === 'cover') {
      const scaleW = outW / img.naturalWidth;
      const scaleH = outH / img.naturalHeight;
      const scale = Math.max(scaleW, scaleH);
      dw = img.naturalWidth * scale;
      dh = img.naturalHeight * scale;
      dx = -(dw / 2);
      dy = -(dh / 2);
    } else if (fitMode === 'contain') {
      const scaleW = outW / img.naturalWidth;
      const scaleH = outH / img.naturalHeight;
      const scale = Math.min(scaleW, scaleH);
      dw = img.naturalWidth * scale;
      dh = img.naturalHeight * scale;
      dx = -(dw / 2);
      dy = -(dh / 2);
    }

    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    ctx.restore();

    // Text watermark
    if (watermark.textEnabled && watermark.text) {
      ctx.save();
      ctx.globalAlpha = watermark.textOpacity / 100;
      ctx.font = `${watermark.textSize}px ${watermark.textFont || 'sans-serif'}`;
      ctx.fillStyle = watermark.textColor || '#ffffff';
      const pos = PixUtils.getWatermarkPos(watermark.textPosition, canvas.width, canvas.height);
      const metrics = ctx.measureText(watermark.text);
      ctx.fillText(watermark.text, pos.x - metrics.width / 2, pos.y);
      ctx.restore();
    }

    // Logo watermark
    if (watermark.logoEnabled && watermark.logoSrc) {
      try {
        const logo = await PixUtils.loadImage(watermark.logoSrc);
        ctx.save();
        ctx.globalAlpha = watermark.logoOpacity / 100;
        const lw = (watermark.logoSize / 100) * canvas.width;
        const lh = (lw / logo.naturalWidth) * logo.naturalHeight;
        const pos = PixUtils.getWatermarkPos(watermark.logoPosition, canvas.width, canvas.height);
        ctx.drawImage(logo, pos.x - lw / 2, pos.y - lh / 2, lw, lh);
        ctx.restore();
      } catch(e) {}
    }

    return canvas;
  },

  getWatermarkPos(position, w, h) {
    const pad = 24;
    const map = {
      'top-left':     { x: pad + w * 0.1, y: pad + h * 0.05 },
      'top-center':   { x: w / 2, y: pad + h * 0.05 },
      'top-right':    { x: w - pad - w * 0.1, y: pad + h * 0.05 },
      'center':       { x: w / 2, y: h / 2 },
      'bottom-left':  { x: pad + w * 0.1, y: h - pad - h * 0.05 },
      'bottom-center':{ x: w / 2, y: h - pad - h * 0.05 },
      'bottom-right': { x: w - pad - w * 0.1, y: h - pad - h * 0.05 },
    };
    return map[position] || { x: w / 2, y: h - 40 };
  },

  async estimateSize(originalSrc, settings, format, quality) {
    try {
      const canvas = await PixUtils.processImage(originalSrc, settings);
      const blob = await PixUtils.canvasToBlob(canvas, format, quality);
      return blob ? blob.size : 0;
    } catch(e) { return 0; }
  }
};
