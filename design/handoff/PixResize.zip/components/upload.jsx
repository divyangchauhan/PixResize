// PixResize — Upload Zone + Image List components

const DEFAULT_SETTINGS = {
  resize: {
    enabled: false,
    mode: 'pixels', // pixels | percent | preset
    width: '',
    height: '',
    percent: '100',
    preset: '',
    lockAspect: true,
    fitMode: 'contain', // contain | cover | stretch
  },
  transform: {
    rotation: 0,
    flipH: false,
    flipV: false,
    crop: null,
  },
  adjustments: {
    brightness: 100,
    contrast: 100,
    blur: 0,
    grayscale: false,
  },
  watermark: {
    textEnabled: false,
    text: '',
    textSize: 32,
    textColor: '#ffffff',
    textOpacity: 80,
    textPosition: 'bottom-right',
    textFont: 'DM Sans',
    logoEnabled: false,
    logoSrc: null,
    logoSize: 20,
    logoOpacity: 80,
    logoPosition: 'bottom-right',
  },
  output: {
    format: 'jpg',
    quality: 88,
    stripExif: true,
    filename: '{name}_{index}',
  }
};

const PRESETS = [
  { label: '1080p', w: 1920, h: 1080 },
  { label: '4K', w: 3840, h: 2160 },
  { label: 'Instagram', w: 1080, h: 1080 },
  { label: 'Twitter', w: 1200, h: 675 },
  { label: 'Facebook', w: 1200, h: 630 },
  { label: 'LinkedIn', w: 1200, h: 627 },
  { label: 'Thumbnail', w: 1280, h: 720 },
];

// ─── Upload Zone ─────────────────────────────────────────────────────────────
function UploadZone({ onFiles, dark }) {
  const [dragging, setDragging] = React.useState(false);
  const inputRef = React.useRef();

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length) onFiles(files);
  };

  const handleInput = (e) => {
    const files = Array.from(e.target.files).filter(f => f.type.startsWith('image/'));
    if (files.length) onFiles(files);
    e.target.value = '';
  };

  return (
    <div
      className={`upload-zone ${dragging ? 'dragging' : ''}`}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current.click()}
      style={{ cursor: 'pointer' }}
    >
      <input ref={inputRef} type="file" multiple accept="image/*" style={{ display: 'none' }} onChange={handleInput} />
      <div className="upload-icon">
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
          <rect x="5" y="12" width="30" height="22" rx="3" stroke="currentColor" strokeWidth="1.5" fill="none"/>
          <path d="M20 8 L20 24 M14 14 L20 8 L26 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="12" cy="20" r="2" fill="currentColor"/>
        </svg>
      </div>
      <div className="upload-title">{dragging ? 'Drop images here' : 'Drop images or click to upload'}</div>
      <div className="upload-sub">Supports JPG, PNG, WebP, AVIF, GIF · Up to 50 images</div>
    </div>
  );
}

// ─── Image Thumbnail ──────────────────────────────────────────────────────────
function ImageThumb({ item, selected, onClick, onRemove }) {
  return (
    <div className={`img-thumb ${selected ? 'selected' : ''}`} onClick={onClick}>
      <img src={item.src} alt={item.name} />
      <div className="img-thumb-overlay">
        <span className="img-thumb-name">{item.name.length > 14 ? item.name.slice(0,12)+'…' : item.name}</span>
        {item.processed && <span className="img-thumb-badge">✓</span>}
      </div>
      <button className="img-thumb-remove" onClick={e => { e.stopPropagation(); onRemove(item.id); }} title="Remove">×</button>
    </div>
  );
}

// ─── Image List Panel ─────────────────────────────────────────────────────────
function ImageList({ images, selectedId, onSelect, onRemove, onAdd, dark }) {
  return (
    <div className="image-list">
      <div className="panel-header">
        <span>Images <span className="count-badge">{images.length}</span></span>
        <button className="icon-btn" onClick={onAdd} title="Add more images">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M7 1v12M1 7h12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </button>
      </div>
      <div className="thumb-grid">
        {images.map(img => (
          <ImageThumb
            key={img.id}
            item={img}
            selected={img.id === selectedId}
            onClick={() => onSelect(img.id)}
            onRemove={onRemove}
          />
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { UploadZone, ImageList, DEFAULT_SETTINGS, PRESETS });
