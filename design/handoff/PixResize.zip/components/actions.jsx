// PixResize — Action Bar (download, clipboard, base64, undo/redo)

function ActionBar({ image, settings, images, onUndo, onRedo, onReset, canUndo, canRedo, onProcessAll, processing }) {
  const [busy, setBusy] = React.useState(false);
  const [copied, setCopied] = React.useState(false);
  const [base64Modal, setBase64Modal] = React.useState(false);
  const [base64String, setBase64String] = React.useState('');

  const getFilename = (img, index, ext) => {
    const tpl = settings.output.filename || '{name}_{index}';
    const base = img.name.replace(/\.[^.]+$/, '');
    return tpl
      .replace('{name}', base)
      .replace('{index}', String(index + 1).padStart(2, '0'))
      + '.' + ext;
  };

  const downloadSingle = async () => {
    if (!image || busy) return;
    setBusy(true);
    try {
      const canvas = await PixUtils.processImage(image.src, settings);
      const blob = await PixUtils.canvasToBlob(canvas, settings.output.format, settings.output.quality);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = getFilename(image, 0, settings.output.format);
      a.click();
      URL.revokeObjectURL(url);
    } finally { setBusy(false); }
  };

  const downloadAllZip = async () => {
    if (!images.length || busy) return;
    setBusy(true);
    try {
      // Use fflate for ZIP
      const script = document.getElementById('fflate-script');
      if (!script) {
        await new Promise((res, rej) => {
          const s = document.createElement('script');
          s.id = 'fflate-script';
          s.src = 'https://unpkg.com/fflate@0.8.2/umd/index.js';
          s.onload = res; s.onerror = rej;
          document.head.appendChild(s);
        });
      }

      const files = {};
      for (let i = 0; i < images.length; i++) {
        const img = images[i];
        const canvas = await PixUtils.processImage(img.src, settings);
        const blob = await PixUtils.canvasToBlob(canvas, settings.output.format, settings.output.quality);
        const ab = await blob.arrayBuffer();
        files[getFilename(img, i, settings.output.format)] = new Uint8Array(ab);
      }

      const zipped = fflate.zipSync(files, { level: 1 });
      const zipBlob = new Blob([zipped], { type: 'application/zip' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'pixresize_export.zip';
      a.click();
      URL.revokeObjectURL(url);
    } finally { setBusy(false); }
  };

  const copyToClipboard = async () => {
    if (!image || busy) return;
    setBusy(true);
    try {
      const canvas = await PixUtils.processImage(image.src, settings);
      canvas.toBlob(async (blob) => {
        try {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob })
          ]);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        } catch (e) {
          alert('Clipboard copy failed. Try a different browser.');
        }
      }, 'image/png');
    } finally { setBusy(false); }
  };

  const exportBase64 = async () => {
    if (!image || busy) return;
    setBusy(true);
    try {
      const canvas = await PixUtils.processImage(image.src, settings);
      const mime = settings.output.format === 'jpg' ? 'image/jpeg'
        : settings.output.format === 'png' ? 'image/png'
        : settings.output.format === 'webp' ? 'image/webp'
        : 'image/avif';
      const dataUrl = canvas.toDataURL(mime, settings.output.quality / 100);
      setBase64String(dataUrl);
      setBase64Modal(true);
    } finally { setBusy(false); }
  };

  const copyBase64 = () => {
    navigator.clipboard.writeText(base64String).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <>
      <div className="action-bar">
        <div className="action-group">
          <button className="action-btn-sm icon-only" onClick={onUndo} disabled={!canUndo} title="Undo">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2 5h7a4 4 0 010 8H6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" fill="none"/>
              <path d="M5 2L2 5l3 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <button className="action-btn-sm icon-only" onClick={onRedo} disabled={!canRedo} title="Redo">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M12 5H5a4 4 0 000 8h3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" fill="none"/>
              <path d="M9 2l3 3-3 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <button className="action-btn-sm" onClick={onReset} title="Reset to original">Reset</button>
        </div>

        <div className="action-group">
          <button className="action-btn-sm" onClick={copyToClipboard} disabled={!image || busy} title="Copy to clipboard">
            {copied ? '✓ Copied' : 'Copy'}
          </button>
          <button className="action-btn-sm" onClick={exportBase64} disabled={!image || busy} title="Export as Base64">
            Base64
          </button>
          <button className="action-btn-sm" onClick={downloadSingle} disabled={!image || busy} title="Download current image">
            {busy ? '…' : '↓ Download'}
          </button>
          <button className="action-btn-primary" onClick={downloadAllZip} disabled={images.length < 1 || busy} title="Bulk download as ZIP">
            {busy ? 'Zipping…' : `↓ ZIP (${images.length})`}
          </button>
        </div>
      </div>

      {base64Modal && (
        <div className="modal-overlay" onClick={() => setBase64Modal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <span>Base64 Export</span>
              <button className="modal-close" onClick={() => setBase64Modal(false)}>×</button>
            </div>
            <textarea className="base64-area" readOnly value={base64String} rows={6} />
            <div className="modal-footer">
              <button className="action-btn-primary" onClick={copyBase64}>
                {copied ? '✓ Copied!' : 'Copy to clipboard'}
              </button>
              <span className="modal-info">{PixUtils.formatBytes(base64String.length)} string</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

Object.assign(window, { ActionBar });
