// PixResize — Preview Panel (Before/After + Canvas preview)

function PreviewPanel({ image, settings, processedCanvas, showBeforeAfter, onToggleBeforeAfter, processing }) {
  const [sliderX, setSliderX] = React.useState(50);
  const [dragging, setDragging] = React.useState(false);
  const containerRef = React.useRef();
  const processedCanvasRef = React.useRef();

  // Draw processed canvas into display canvas
  React.useEffect(() => {
    if (!processedCanvas || !processedCanvasRef.current) return;
    const displayCanvas = processedCanvasRef.current;
    displayCanvas.width = processedCanvas.width;
    displayCanvas.height = processedCanvas.height;
    const ctx = displayCanvas.getContext('2d');
    ctx.drawImage(processedCanvas, 0, 0);
  }, [processedCanvas]);

  const handleMouseMove = React.useCallback((e) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pct = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    setSliderX(pct);
  }, [dragging]);

  const handleMouseUp = React.useCallback(() => setDragging(false), []);

  React.useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, handleMouseMove, handleMouseUp]);

  if (!image) {
    return (
      <div className="preview-empty">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" opacity="0.3">
          <rect x="4" y="8" width="40" height="32" rx="3" stroke="currentColor" strokeWidth="1.5" fill="none"/>
          <circle cx="16" cy="20" r="4" stroke="currentColor" strokeWidth="1.5" fill="none"/>
          <path d="M4 34l10-10 8 8 6-6 10 10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span>No image selected</span>
      </div>
    );
  }

  return (
    <div className="preview-panel">
      <div className="preview-toolbar">
        <div className="preview-info">
          {image.width && <span className="info-chip">{image.width} × {image.height}</span>}
          <span className="info-chip">{PixUtils.formatBytes(image.size)}</span>
        </div>
        <div className="preview-actions">
          <button
            className={`preview-btn ${showBeforeAfter ? 'active' : ''}`}
            onClick={onToggleBeforeAfter}
            title="Before/After comparison"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M7 2v10M2 2h3v10H2zM9 2h3v10H9z" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
            </svg>
            Before/After
          </button>
        </div>
      </div>

      <div
        className="preview-canvas-wrap"
        ref={containerRef}
        style={{ position: 'relative', overflow: 'hidden' }}
      >
        {processing && (
          <div className="processing-overlay">
            <div className="spinner"></div>
            <span>Processing…</span>
          </div>
        )}

        {showBeforeAfter ? (
          <div className="ba-container" style={{ position: 'relative', width: '100%', height: '100%' }}>
            {/* After (processed) — full width underneath */}
            <div className="ba-after" style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {processedCanvas
                ? <canvas ref={processedCanvasRef} className="preview-img" />
                : <img src={image.src} alt="after" className="preview-img" />
              }
              <span className="ba-label ba-label-after">After</span>
            </div>
            {/* Before — clipped to left of slider */}
            <div
              className="ba-before"
              style={{
                position: 'absolute', inset: 0,
                clipPath: `inset(0 ${100 - sliderX}% 0 0)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }}
            >
              <img src={image.src} alt="before" className="preview-img" />
              <span className="ba-label ba-label-before">Before</span>
            </div>
            {/* Slider handle */}
            <div
              className="ba-slider"
              style={{ left: `${sliderX}%` }}
              onMouseDown={() => setDragging(true)}
            >
              <div className="ba-slider-line"></div>
              <div className="ba-slider-handle">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M5 8l-3-3v6l3-3zM11 8l3-3v6l-3-3z" fill="currentColor"/>
                </svg>
              </div>
            </div>
          </div>
        ) : (
          <div className="single-preview" style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {processedCanvas
              ? <canvas ref={processedCanvasRef} className="preview-img" />
              : <img src={image.src} alt="preview" className="preview-img" />
            }
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { PreviewPanel });
