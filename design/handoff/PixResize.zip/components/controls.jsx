// PixResize — Controls Panel components

// ─── Shared UI Primitives ─────────────────────────────────────────────────────

function Slider({ label, value, min, max, step = 1, unit = '', onChange }) {
  return (
    <div className="ctrl-row">
      <label className="ctrl-label">{label}</label>
      <div className="ctrl-slider-wrap">
        <input
          type="range" min={min} max={max} step={step}
          value={value}
          onChange={e => onChange(Number(e.target.value))}
          className="ctrl-slider"
        />
        <span className="ctrl-value">{value}{unit}</span>
      </div>
    </div>
  );
}

function NumberInput({ value, onChange, min, max, placeholder }) {
  return (
    <input
      type="number" className="num-input"
      value={value} min={min} max={max}
      placeholder={placeholder}
      onChange={e => onChange(e.target.value)}
    />
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <div className="ctrl-row">
      <label className="ctrl-label">{label}</label>
      <button
        className={`toggle-btn ${checked ? 'on' : ''}`}
        onClick={() => onChange(!checked)}
      >
        <span className="toggle-knob"></span>
      </button>
    </div>
  );
}

function SectionTitle({ label, icon, open, onToggle }) {
  return (
    <button className={`section-title ${open ? 'open' : ''}`} onClick={onToggle}>
      <span className="section-icon">{icon}</span>
      <span>{label}</span>
      <svg className="chevron" width="12" height="12" viewBox="0 0 12 12" fill="none">
        <path d="M3 4.5l3 3 3-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </button>
  );
}

// ─── Resize Section ──────────────────────────────────────────────────────────
function ResizeSection({ settings, onChange, imgW, imgH }) {
  const [open, setOpen] = React.useState(true);
  const { resize } = settings;
  const s = resize;

  const setResize = (patch) => onChange({ ...settings, resize: { ...s, ...patch } });

  const handleWidthChange = (val) => {
    if (s.lockAspect && imgW && imgH && val) {
      const ratio = imgH / imgW;
      setResize({ width: val, height: Math.round(parseInt(val) * ratio) || '' });
    } else {
      setResize({ width: val });
    }
  };

  const handleHeightChange = (val) => {
    if (s.lockAspect && imgW && imgH && val) {
      const ratio = imgW / imgH;
      setResize({ height: val, width: Math.round(parseInt(val) * ratio) || '' });
    } else {
      setResize({ height: val });
    }
  };

  const applyPreset = (preset) => {
    setResize({ enabled: true, mode: 'pixels', width: preset.w, height: preset.h, preset: preset.label, lockAspect: false });
  };

  return (
    <div className="ctrl-section">
      <SectionTitle label="Resize" icon={
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <rect x="1" y="1" width="8" height="8" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none"/>
          <rect x="5" y="5" width="8" height="8" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none" strokeDasharray="2 1.5"/>
          <path d="M10 1l3 3M1 10l3 3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      } open={open} onToggle={() => setOpen(!open)} />

      {open && (
        <div className="ctrl-body">
          <Toggle label="Enable resize" checked={s.enabled} onChange={v => setResize({ enabled: v })} />

          {s.enabled && (
            <>
              <div className="seg-ctrl">
                {['pixels','percent','preset'].map(m => (
                  <button key={m} className={s.mode === m ? 'active' : ''} onClick={() => setResize({ mode: m })}>
                    {m === 'pixels' ? 'px' : m === 'percent' ? '%' : 'Preset'}
                  </button>
                ))}
              </div>

              {s.mode === 'pixels' && (
                <div className="dim-row">
                  <div className="dim-field">
                    <label>W</label>
                    <NumberInput value={s.width} placeholder={imgW || 'W'} min={1} max={8000} onChange={handleWidthChange} />
                  </div>
                  <button
                    className={`lock-btn ${s.lockAspect ? 'locked' : ''}`}
                    onClick={() => setResize({ lockAspect: !s.lockAspect })}
                    title={s.lockAspect ? 'Unlock aspect ratio' : 'Lock aspect ratio'}
                  >
                    {s.lockAspect ? (
                      <svg width="12" height="14" viewBox="0 0 12 14" fill="none">
                        <rect x="1" y="6" width="10" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none"/>
                        <path d="M3 6V4a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
                      </svg>
                    ) : (
                      <svg width="12" height="14" viewBox="0 0 12 14" fill="none">
                        <rect x="1" y="6" width="10" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none"/>
                        <path d="M8 6V4a3 3 0 00-3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
                      </svg>
                    )}
                  </button>
                  <div className="dim-field">
                    <label>H</label>
                    <NumberInput value={s.height} placeholder={imgH || 'H'} min={1} max={8000} onChange={handleHeightChange} />
                  </div>
                </div>
              )}

              {s.mode === 'percent' && (
                <Slider label="Scale" value={parseFloat(s.percent)} min={1} max={400} unit="%" onChange={v => setResize({ percent: v })} />
              )}

              {s.mode === 'preset' && (
                <div className="preset-grid">
                  {PRESETS.map(p => (
                    <button
                      key={p.label}
                      className={`preset-btn ${s.preset === p.label ? 'active' : ''}`}
                      onClick={() => applyPreset(p)}
                    >
                      <span className="preset-name">{p.label}</span>
                      <span className="preset-dim">{p.w}×{p.h}</span>
                    </button>
                  ))}
                </div>
              )}

              {(s.mode === 'pixels' || s.mode === 'preset') && (
                <div className="ctrl-row">
                  <label className="ctrl-label">Fit mode</label>
                  <div className="seg-ctrl small">
                    {['contain','cover','stretch'].map(m => (
                      <button key={m} className={s.fitMode === m ? 'active' : ''} onClick={() => setResize({ fitMode: m })}>
                        {m.charAt(0).toUpperCase() + m.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Transform Section ────────────────────────────────────────────────────────
function TransformSection({ settings, onChange }) {
  const [open, setOpen] = React.useState(false);
  const { transform } = settings;
  const setTransform = (patch) => onChange({ ...settings, transform: { ...transform, ...patch } });

  return (
    <div className="ctrl-section">
      <SectionTitle label="Transform" icon={
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M7 1a6 6 0 11-6 6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
          <path d="M1 4V1h3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      } open={open} onToggle={() => setOpen(!open)} />

      {open && (
        <div className="ctrl-body">
          <div className="ctrl-row">
            <label className="ctrl-label">Rotate</label>
            <div className="btn-group">
              {[['CCW', -90], ['180°', 180], ['CW', 90]].map(([lbl, deg]) => (
                <button key={lbl} className="action-btn"
                  onClick={() => setTransform({ rotation: ((transform.rotation + deg) % 360 + 360) % 360 })}>
                  {lbl}
                </button>
              ))}
            </div>
          </div>
          <div className="ctrl-row">
            <label className="ctrl-label">Flip</label>
            <div className="btn-group">
              <button className={`action-btn ${transform.flipH ? 'active' : ''}`}
                onClick={() => setTransform({ flipH: !transform.flipH })}>Horizontal</button>
              <button className={`action-btn ${transform.flipV ? 'active' : ''}`}
                onClick={() => setTransform({ flipV: !transform.flipV })}>Vertical</button>
            </div>
          </div>
          {transform.rotation !== 0 && (
            <div className="ctrl-hint">Rotation: {transform.rotation}°</div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Adjustments Section ──────────────────────────────────────────────────────
function AdjustmentsSection({ settings, onChange }) {
  const [open, setOpen] = React.useState(false);
  const { adjustments } = settings;
  const setAdj = (patch) => onChange({ ...settings, adjustments: { ...adjustments, ...patch } });

  return (
    <div className="ctrl-section">
      <SectionTitle label="Adjustments" icon={
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <circle cx="4" cy="4" r="2" stroke="currentColor" strokeWidth="1.2" fill="none"/>
          <circle cx="10" cy="10" r="2" stroke="currentColor" strokeWidth="1.2" fill="none"/>
          <path d="M1 4h2M6 4h7M1 10h7M12 10h1M4 2v2M10 8v2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      } open={open} onToggle={() => setOpen(!open)} />

      {open && (
        <div className="ctrl-body">
          <Slider label="Brightness" value={adjustments.brightness} min={0} max={200} unit="%" onChange={v => setAdj({ brightness: v })} />
          <Slider label="Contrast" value={adjustments.contrast} min={0} max={200} unit="%" onChange={v => setAdj({ contrast: v })} />
          <Slider label="Blur" value={adjustments.blur} min={0} max={20} step={0.5} unit="px" onChange={v => setAdj({ blur: v })} />
          <Toggle label="Grayscale" checked={adjustments.grayscale} onChange={v => setAdj({ grayscale: v })} />
        </div>
      )}
    </div>
  );
}

// ─── Watermark Section ────────────────────────────────────────────────────────
function WatermarkSection({ settings, onChange }) {
  const [open, setOpen] = React.useState(false);
  const { watermark } = settings;
  const setWM = (patch) => onChange({ ...settings, watermark: { ...watermark, ...patch } });
  const logoInputRef = React.useRef();

  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setWM({ logoSrc: ev.target.result });
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const positions = ['top-left','top-center','top-right','center','bottom-left','bottom-center','bottom-right'];

  return (
    <div className="ctrl-section">
      <SectionTitle label="Watermark" icon={
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M2 10L6 4l3 4 2-2.5 3 4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
          <rect x="1" y="1" width="12" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none"/>
        </svg>
      } open={open} onToggle={() => setOpen(!open)} />

      {open && (
        <div className="ctrl-body">
          {/* Text Watermark */}
          <Toggle label="Text watermark" checked={watermark.textEnabled} onChange={v => setWM({ textEnabled: v })} />
          {watermark.textEnabled && (
            <div className="sub-section">
              <input className="text-input" type="text" placeholder="Watermark text…"
                value={watermark.text} onChange={e => setWM({ text: e.target.value })} />
              <Slider label="Size" value={watermark.textSize} min={8} max={120} unit="px" onChange={v => setWM({ textSize: v })} />
              <Slider label="Opacity" value={watermark.textOpacity} min={0} max={100} unit="%" onChange={v => setWM({ textOpacity: v })} />
              <div className="ctrl-row">
                <label className="ctrl-label">Color</label>
                <input type="color" className="color-input" value={watermark.textColor}
                  onChange={e => setWM({ textColor: e.target.value })} />
              </div>
              <div className="ctrl-row">
                <label className="ctrl-label">Position</label>
                <select className="select-input" value={watermark.textPosition} onChange={e => setWM({ textPosition: e.target.value })}>
                  {positions.map(p => <option key={p} value={p}>{p.replace('-',' ')}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Logo Watermark */}
          <Toggle label="Logo watermark" checked={watermark.logoEnabled} onChange={v => setWM({ logoEnabled: v })} />
          {watermark.logoEnabled && (
            <div className="sub-section">
              <input ref={logoInputRef} type="file" accept="image/*" style={{ display:'none' }} onChange={handleLogoUpload} />
              <button className="action-btn full-width" onClick={() => logoInputRef.current.click()}>
                {watermark.logoSrc ? '↺ Replace logo' : '+ Upload logo image'}
              </button>
              {watermark.logoSrc && (
                <>
                  <Slider label="Size" value={watermark.logoSize} min={5} max={80} unit="%" onChange={v => setWM({ logoSize: v })} />
                  <Slider label="Opacity" value={watermark.logoOpacity} min={0} max={100} unit="%" onChange={v => setWM({ logoOpacity: v })} />
                  <div className="ctrl-row">
                    <label className="ctrl-label">Position</label>
                    <select className="select-input" value={watermark.logoPosition} onChange={e => setWM({ logoPosition: e.target.value })}>
                      {positions.map(p => <option key={p} value={p}>{p.replace('-',' ')}</option>)}
                    </select>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Output Section ───────────────────────────────────────────────────────────
function OutputSection({ settings, onChange, sizeEstimate }) {
  const [open, setOpen] = React.useState(true);
  const { output } = settings;
  const setOut = (patch) => onChange({ ...settings, output: { ...output, ...patch } });
  const lossy = ['jpg','webp','avif'].includes(output.format);

  return (
    <div className="ctrl-section">
      <SectionTitle label="Output" icon={
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M7 1v8M4 6l3 3 3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 11h10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      } open={open} onToggle={() => setOpen(!open)} />

      {open && (
        <div className="ctrl-body">
          <div className="ctrl-row">
            <label className="ctrl-label">Format</label>
            <div className="seg-ctrl">
              {['jpg','png','webp','avif'].map(f => (
                <button key={f} className={output.format === f ? 'active' : ''} onClick={() => setOut({ format: f })}>
                  {f.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {lossy && (
            <Slider label="Quality" value={output.quality} min={1} max={100} unit="%" onChange={v => setOut({ quality: v })} />
          )}

          <Toggle label="Strip EXIF" checked={output.stripExif} onChange={v => setOut({ stripExif: v })} />

          <div className="ctrl-row">
            <label className="ctrl-label">Filename</label>
            <input className="text-input small" type="text" value={output.filename}
              onChange={e => setOut({ filename: e.target.value })}
              placeholder="{name}_{index}" />
          </div>

          {sizeEstimate > 0 && (
            <div className="size-estimate">
              <span className="size-dot"></span>
              Est. size: <strong>{PixUtils.formatBytes(sizeEstimate)}</strong>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ResizeSection, TransformSection, AdjustmentsSection, WatermarkSection, OutputSection, Slider, Toggle, SectionTitle });
